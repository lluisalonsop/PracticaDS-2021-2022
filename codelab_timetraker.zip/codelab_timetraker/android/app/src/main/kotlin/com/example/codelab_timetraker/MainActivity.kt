package com.example.codelab_timetraker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
